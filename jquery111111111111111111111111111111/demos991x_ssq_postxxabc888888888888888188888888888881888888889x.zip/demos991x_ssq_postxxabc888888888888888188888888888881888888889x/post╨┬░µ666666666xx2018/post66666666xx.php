
<center>



<h3   style=color:#FF0000>



<form    action="post66666666xx.php" method="post">
 

<table border="2">
<tr>
<td>

<h3   style=color:#FF0000>



请选择前区号码最少选5个##：<br><hr>

<table border="2">
<tr>


<td>

<td>

<td>

<td>

<h3   style=color:#FF0000>


<input type="checkbox" name="a['1a']" value="1">1<br />
<td/>
<td>



<h3   style=color:#FF0000>


<input type="checkbox" name="a['2a']"
value="2">2<br>

<td/>

<td>

<h3   style=color:#FF0000>


<input type="checkbox" name="a['3a']" value="3">3<br />

<td/>
<td>

<h3   style=color:#FF0000>


<input type="checkbox" name="a['4a']" value="4">4<br />
<td/>

<td>


<h3   style=color:#FF0000>


<input type="checkbox" name="a['5a']" value="5">5<br />





<td/>


<td>


<h3   style=color:#FF0000>


<input type="checkbox" name="a['a6']" value="6">6<br />

<td/>

<td>



<h3   style=color:#FF0000>

<input type="checkbox" name="a['a7']" value="7">7<br />
<td/>
<td>



<h3   style=color:#FF0000>


<input type="checkbox" name="a['a8']" value="8">8<br />

<td/>

<td>

<tr/>

<tr>


<td>

<input type="checkbox" name="l['l']" value="0">0<br />

<input type="checkbox" name="0['0']" value="0">0<br />
<td/>

<td>




<tr/>


<tr>



<input type="checkbox" name="0['0']" value="0">0<br />

<input type="checkbox" name="0['0']" value="0">0<br />
<td/>



<td>

<tb>


<td>



<h3   style=color:#FF0000>

<input type="checkbox" name="a['a9']" value="9">9<br />

<td/>
<td>



<h3   style=color:#FF0000>

<input type="checkbox" name="a10['a10']" value="10">10<br />

<td/>

<td>


<h3   style=color:#FF0000>

<input type="checkbox" name="a['a11']" value="11">11<br />

<td/>


<td>


<h3   style=color:#FF0000>

<input type="checkbox" name="a['a12']" value="12">12<br />


<td/>

<td>




<h3   style=color:#FF0000>


<input type="checkbox" name="b['b13']" value="13">13<br />


<td/>

<td>


<h3   style=color:#FF0000>

<input type="checkbox" name="b['b14']" value="14">14<br />

<td/>

<td>


<h3   style=color:#FF0000>


<input type="checkbox" name="b['b15']" value="15">15<br />


<td/>

<td>



<h3   style=color:#FF0000>

<input type="checkbox" name="b['b16']" value="16">16<br />


<td/>


<td>

<tr/>


<tr>


<td>

<input type="checkbox" name="0['0']" value="0">0<br />

<input type="checkbox" name="0['0']" value="0">0<br />
<td/>


<td>

<h3   style=color:#FF0000>

<input type="checkbox" name="b['b17']" value="17">17<br />

<td/>


<td>


<h3   style=color:#FF0000>

<input type="checkbox" name="b['b18']" value="18">18<br />


<td/>

<td>


<h3   style=color:#FF0000>

<input type="checkbox" name="b['b19']" value="19">19<br />

<td/>

<td>


<h3   style=color:#FF0000>

<input type="checkbox" name="b['b20']" value="20">20<br />


<td/>

<td>


<h3   style=color:#FF0000>

<input type="checkbox" name="b['b21']" value="21">21<br />


<td/>


<td>


<h3   style=color:#FF0000>


<input type="checkbox" name="b['b22']" value="22">22<br />

<td/>


<td>


<h3   style=color:#FF0000>

<input type="checkbox" name="b['b23']" value="23">23<br />


<td/>

<td>

<h3   style=color:#FF0000>

<input type="checkbox" name="b['b24']" value="24">24<br />

<td/>

<tr/>

<tr>

<td>

<input type="checkbox" name="0['0']" value="0">0<br />

<input type="checkbox" name="0['0']" value="0">0<br />
<td/>


<td>

<h3   style=color:#FF0000>

<input type="checkbox" name="c['c25']" value="25">25<br />


<td/>
<td>


<h3   style=color:#FF0000>


<input type="checkbox" name="c['c26']" value="26">26<br />


<td/>
<td>


<h3   style=color:#FF0000>

<input type="checkbox" name="c['c27']" value="27">27<br />


<td/>

<td>


<h3   style=color:#FF0000>

<input type="checkbox" name="c['c28']" value="28">28<br />

<td/>

<td>

<h3   style=color:#FF0000>

<input type="checkbox" name="c['c29']" value="29">29<br />

<td/>

<td>

<h3   style=color:#FF0000>


<input type="checkbox" name="c['c30']" value="30">30<br />

<td/>

<td>


<h3   style=color:#FF0000>

<input type="checkbox" name="c['c31']" value="31">31<br />

<td/>

<tr/>

<tr>


<td>

<input type="checkbox" name="0['0']" value="0">0<br />

<input type="checkbox" name="0['0']" value="0">0<br />
<td/>

<td>


<h3   style=color:#FF0000>

<input type="checkbox" name="c['c32']" value="32">32<br />

<td/>

<td>

<h3   style=color:#FF0000>


<input type="checkbox" name="c['c33']" value="33">33<br />

<td/>

<td>


<h3   style=color:#FF0000>

<input type="checkbox" name="c['c34']" value="34">34<br />


<td/>
<td>


<h3   style=color:#FF0000>

<input type="checkbox" name="c['c35']" value="35">35<br />


<td/>
<td>

<input type="checkbox" name="0['0']" value="0">0<br />

<input type="checkbox" name="0['0']" value="0">0<br />
<td/>

<tr/>



<table/>

<br>

<hr>



<input     style="font-size:40px"    type="submit"   value="开始选号" >




</form>

<div    style=color:#FF0000>


<h3>两行三列前区：{可合2为1}</h3>
<table border="1">
<tr>
  <td>


<?php
echo "<pre>";
echo "<center>";
echo "<h2  style=color:#FF0000  >双色球POST勾选随机版前区</>";

echo "<h2  style=color:#FF0000 >您勾选的号码是</><td>";




print_r ($_POST);   //打印出勾选号码

$x=mt_rand(1,7);
echo "<h2 style=color:#FF0000 >您勾选后随机的号码是</><br/>";

echo "<hr>";

print_r(array_rand($_POST['a'],$x));   //在勾选号码中随机


echo "<hr>";



$x1=mt_rand(0,5);

print_r(array_rand($_POST['b'],$x1));   //在勾选号码中随机

echo "<hr>";



$x2=mt_rand(0,5);

print_r(array_rand($_POST['c'],$x2));   //在勾选号码中随机


$x3=mt_rand(0,5);

print_r(array_rand($_POST,$x3));   //在勾选号码中随机



?>
<td/>

</tr>

</table>










































