<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="jquery.mobile-1.4.5/jquery.mobile-1.4.5.min.css">
<script src="jquery-1.10.2/jquery.min.js">
</script>
<script src="jquery.mobile-1.4.5/jquery.mobile-1.4.5.min.js"></script>
</head>
<body>

​
<div data-role="page">
  <div data-role="header">
  <h1>七乐彩复选框</h1>
  </div>
​
  <div data-role="main" class="ui-content">
    <form method="post" action="jquerymd88888888777777x.php">

      <input type="submit" data-inline="true" value="提交开始">

        <fieldset data-role="controlgroup" data-type="horizontal">

          <label for="red">01</label>
          <input type="checkbox" name="a['1']" id="red" value="1">
          <label for="green">02</label>
          <input type="checkbox" name="a['2']" id="green" value="2">
          <label for="blue">03</label>
          <input type="checkbox" name="a['3']" id="blue" value="3">  


  <label for="red">04</label>
          <input type="checkbox" name="a['4']" id="red" value="4">
          <label for="green">05</label>
          <input type="checkbox" name="a['5']" id="green" value="5">
          <label for="blue">06</label>
          <input type="checkbox" name="a['6']" id="blue" value="6">  

   

  <label for="red">07</label>
          <input type="checkbox" name="a['7']" id="red" value="7">
          <label for="green">08</label>
          <input type="checkbox" name="a['8']" id="green" value="8">
          <label for="blue">09</label>
          <input type="checkbox" name="a['9']" id="blue" value="9">  
  

  <label for="red">10</label>
          <input type="checkbox" name="a['10']" id="red" value="10">
          <label for="green">11</label>
          <input type="checkbox" name="a['11']" id="green" value="11">
          <label for="blue">12</label>
          <input type="checkbox" name="a['12']" id="blue" value="12">  

   

  <label for="red">13</label>
          <input type="checkbox" name="a['13']" id="red" value="13">
          <label for="green">14</label>
          <input type="checkbox" name="a['14']" id="green" value="14">
          <label for="blue">15</label>
          <input type="checkbox" name="a['15']" id="blue" value="15"> 


  <label for="red">16</label>
          <input type="checkbox" name="a['16']" id="red" value="16">
          <label for="green">17</label>
          <input type="checkbox" name="a['17']" id="green" value="17">
          <label for="blue">18</label>
          <input type="checkbox" name="a['18']" id="blue" value="18">  

 

  <label for="red">19</label>
          <input type="checkbox" name="a['19']" id="red" value="19">
          <label for="green">20</label>
          <input type="checkbox" name="a['20']" id="green" value="20">
          <label for="blue">21</label>
          <input type="checkbox" name="a['21']" id="blue" value="21"> 


  <label for="red">22</label>
          <input type="checkbox" name="a['22']" id="red" value="22">
          <label for="green">23</label>
          <input type="checkbox" name="a['23']" id="green" value="23">
          <label for="blue">24</label>
          <input type="checkbox" name="a['24']" id="blue" value="24">  



  <label for="red">25</label>
          <input type="checkbox" name="a['25']" id="red" value="25">
          <label for="green">26</label>
          <input type="checkbox" name="a['26']" id="green" value="26">
          <label for="blue">27</label>
          <input type="checkbox" name="a['27']" id="blue" value="27">  


  <label for="red">28</label>
          <input type="checkbox" name="a['28']" id="red" value="28">
          <label for="green">29</label>
          <input type="checkbox" name="a['29']" id="green" value="29">
          <label for="blue">30</label>
          <input type="checkbox" name="a['30']" id="blue" value="30">  



   </fieldset>


    <fieldset data-role="controlgroup" data-type="horizontal">

      <legend>请选择您喜爱的号码：</legend>

          <label for="red">b1</label>
          <input type="checkbox" name="b['b1']" id="red" value="b1">
          <label for="green">b2</label>
          <input type="checkbox" name="b['b2']" id="green" value="b2">
          <label for="blue">b3</label>
          <input type="checkbox" name="b['b3']" id="blue" value="b3">  

          <label for="red">b4</label>
          <input type="checkbox" name="b['b4']" id="red" value="b4">
          <label for="green">b5</label>
          <input type="checkbox" name="b['b5']" id="green" value="b5">
          <label for="blue">b6</label>
          <input type="checkbox" name="b['b6']" id="blue" value="b6">  

 

  <label for="red">b7</label>
          <input type="checkbox" name="b['b7']" id="red" value="b7">
          <label for="green">b8</label>
          <input type="checkbox" name="b['b8']" id="green" value="b8">
          <label for="blue">b9</label>
          <input type="checkbox" name="b['b9']" id="blue" value="b9">  


  <label for="red">b10</label>
          <input type="checkbox" name="b['b10']" id="red" value="b10">
          <label for="green">b11</label>
          <input type="checkbox" name="b['b11']" id="green" value="b11">
          <label for="blue">b12</label>
          <input type="checkbox" name="b['b12']" id="blue" value="b12">  


  <label for="red">b13</label>
          <input type="checkbox" name="b['b13']" id="red" value="b13">
          <label for="green">b14</label>
          <input type="checkbox" name="b['b14']" id="green" value="b14">
          <label for="blue">b15</label>
          <input type="checkbox" name="b['b15']" id="blue" value="b15"> 
 

         <label for="blue">b16</label>
          <input type="checkbox" name="b['b16']" id="blue" value="b16">  

  </fieldset>


      <input type="submit" data-inline="true" value="提交开始">



<?


echo "<hr>";

echo "您选择的前区号码是";

print_r($_POST['a']);   

echo "<hr>";


echo "您选择的后区号码是";

print_r($_POST['b']);   

echo "<hr>";



/*

注释――把php代码放到 form标签内

点击提交按钮不跳转

post_abc_第八版  勾选随机8版模型

已把依赖库下载解压到项目的同级目录下

，即可使用本地路径。


*/



echo "随机后的前区号码";


$x1=mt_rand(7,7);

print_r(array_rand($_POST['a'],$x1));   //在勾选号码中随机

echo "<hr>";

echo "随机后的后区号码";

$b1=mt_rand(1,1);

print_r(array_rand($_POST['b'],$b1));   //在勾选号码中随机


 ?>

    </form>
  </div>
</div>
​
</body>
</html>
​
