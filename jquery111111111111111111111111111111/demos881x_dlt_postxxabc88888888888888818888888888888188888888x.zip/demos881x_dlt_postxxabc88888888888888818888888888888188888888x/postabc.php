<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://apps.bdimg.com/libs/jquerymobile/1.4.5/jquery.mobile-1.4.5.min.css">
<script src="https://apps.bdimg.com/libs/jquery/1.10.2/jquery.min.js"></script>
<script src="https://apps.bdimg.com/libs/jquerymobile/1.4.5/jquery.mobile-1.4.5.min.js"></script>
</head>
<body>
​
<div data-role="page">
  <div data-role="header">
  <h1>复选框</h1>
  </div>
​
  <div data-role="main" class="ui-content">
    <form method="post" action="postabc.php">
      <fieldset data-role="controlgroup">
        <legend>请选择您喜爱的颜色：</legend>
          <label for="red">红色</label>
          <input type="checkbox" name="a" id="red" value="red">
          <label for="green">绿色</label>
          <input type="checkbox" name="b" id="green" value="green">
          <label for="blue">蓝色</label>
          <input type="checkbox" name="c" id="blue" value="blue">  
      </fieldset>
      <input type="submit" data-inline="true" value="提交">

<?

echo "<hr>";

print_r($_POST['b']);   

echo "<hr>";

print_r($_POST['c']);   

echo "<hr>";

print_r($_POST['a']);   

/*

注释――把php代码放到 form标签内

点击提交按钮不跳转

post_abc_第八版  勾选随机8版模型


*/

 ?>

    </form>
  </div>
</div>
​
</body>
</html>
​
